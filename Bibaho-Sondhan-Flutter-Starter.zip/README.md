# বিবাহ সন্ধান (Bibaho Sondhan)

বাংলাদেশের মুসলিম পাত্র-পাত্রীর জন্য বাংলা Android অ্যাপের Flutter UI starter project।

## এই সংস্করণে যা আছে
- বাংলা হোম পেজ ও নিচের নেভিগেশন
- বায়োডাটা ফরমের প্রাথমিক UI ও বয়স ১৮+ যাচাই
- জেলা/উপজেলা নির্বাচন (প্রথম পর্যায়: রাজশাহী, চাঁপাইনবাবগঞ্জ, নওগাঁ)
- বায়োডাটা অনুসন্ধানের UI
- পছন্দের তালিকা ও প্রোফাইলের ডেমো স্ক্রিন
- অ্যাডমিন পর্যালোচনা স্ক্রিনের UI

## গুরুত্বপূর্ণ সীমাবদ্ধতা
এটি এখনো **UI starter / prototype**। এই ZIP-এ Firebase Authentication, Firestore-এ ডেটা সংরক্ষণ, বাস্তব অ্যাডমিন অনুমোদন, ছবি আপলোড, নিরাপদ যোগাযোগ-অনুরোধ, বা APK অন্তর্ভুক্ত/সম্পন্ন নয়। স্ক্রিনের ডেমো ডেটা ফোনে স্থায়ীভাবে সংরক্ষিত হয় না। বাস্তব ব্যবহারকারীর তথ্য নেওয়ার আগে backend, security rules, privacy policy এবং পরীক্ষা সম্পন্ন করতে হবে।

## চালানোর নিয়ম
Flutter SDK ইনস্টল করা কম্পিউটার বা Codespace-এ:
```bash
flutter pub get
flutter run
```
Android APK:
```bash
flutter build apk --release
```

## Firebase যুক্ত করার পরবর্তী ধাপ
1. Firebase Console-এ `com.bibahosondhan.app` Android app-টি ব্যবহার করুন।
2. FlutterFire CLI দিয়ে `flutterfire configure` চালিয়ে `lib/firebase_options.dart` তৈরি করুন।
3. `firebase_core`, `firebase_auth`, `cloud_firestore` যোগ করুন।
4. Firestore rules-এ শুধু authenticated user-এর নিজের biodata create/update, admin-এর review এবং consent-based contact request অনুমোদন করুন।
5. কোনো অবস্থাতেই production rules-এ `allow read, write: if true` ব্যবহার করবেন না।

## নীতিমালা
- প্রথম পর্যায়ে শুধু মুসলিম ব্যবহারকারী।
- প্রথম পর্যায়ের এলাকা: রাজশাহী, চাঁপাইনবাবগঞ্জ, নওগাঁ।
- বায়োডাটা অ্যাডমিন যাচাইয়ের পর প্রকাশ হবে।
- ফোন/যোগাযোগের তথ্য অনুমতি ছাড়া প্রকাশ করা হবে না।
- ছবি ঐচ্ছিক।
