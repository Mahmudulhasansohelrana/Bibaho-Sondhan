import 'package:flutter/material.dart';

void main() => runApp(const BibahoSondhanApp());

const brand = Color(0xFF087B56);
const districts = ['রাজশাহী', 'চাঁপাইনবাবগঞ্জ', 'নওগাঁ'];
const upazilas = <String, List<String>>{
  'রাজশাহী': ['তানোর', 'গোদাগাড়ী', 'মোহনপুর', 'পবা', 'বাগমারা', 'বাঘা', 'চারঘাট', 'দুর্গাপুর'],
  'চাঁপাইনবাবগঞ্জ': ['চাঁপাইনবাবগঞ্জ সদর', 'শিবগঞ্জ', 'গোমস্তাপুর', 'নাচোল', 'ভোলাহাট'],
  'নওগাঁ': ['নওগাঁ সদর', 'আত্রাই', 'রাণীনগর', 'মান্দা', 'মহাদেবপুর', 'পত্নীতলা', 'ধামইরহাট'],
};

class BibahoSondhanApp extends StatelessWidget {
  const BibahoSondhanApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'বিবাহ সন্ধান',
        theme: ThemeData(
          colorScheme: ColorScheme.fromSeed(seedColor: brand),
          scaffoldBackgroundColor: const Color(0xFFF7FAF8),
          useMaterial3: true,
          appBarTheme: const AppBarTheme(
            backgroundColor: brand, foregroundColor: Colors.white,
            centerTitle: false, elevation: 0,
          ),
          inputDecorationTheme: InputDecorationTheme(
            filled: true, fillColor: Colors.white,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: const BorderSide(color: Color(0xFFDDE7E1)),
            ),
          ),
        ),
        home: const MainShell(),
      );
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});
  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int index = 0;
  final pages = const [HomePage(), SearchPage(), BiodataPage(), FavoritesPage(), ProfilePage()];
  @override
  Widget build(BuildContext context) => Scaffold(
        body: IndexedStack(index: index, children: pages),
        bottomNavigationBar: NavigationBar(
          selectedIndex: index,
          onDestinationSelected: (v) => setState(() => index = v),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'হোম'),
            NavigationDestination(icon: Icon(Icons.search), label: 'অনুসন্ধান'),
            NavigationDestination(icon: Icon(Icons.assignment_outlined), label: 'বায়োডাটা'),
            NavigationDestination(icon: Icon(Icons.favorite_border), label: 'পছন্দ'),
            NavigationDestination(icon: Icon(Icons.person_outline), label: 'প্রোফাইল'),
          ],
        ),
      );
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('বিবাহ সন্ধান'), actions: [
          IconButton(onPressed: () => showAboutDialog(context: context, applicationName: 'বিবাহ সন্ধান',
            applicationVersion: '1.0.0', children: const [Text('শুধু মুসলিম ব্যবহারকারীদের জন্য জীবনসঙ্গী অনুসন্ধান প্ল্যাটফর্ম।')]),
            icon: const Icon(Icons.info_outline)),
        ]),
        body: ListView(padding: const EdgeInsets.all(16), children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(color: brand, borderRadius: BorderRadius.circular(20)),
            child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('জীবনসঙ্গী খুঁজুন\\nবিশ্বাস ও সম্মানের সাথে', style: TextStyle(color: Colors.white, fontSize: 23, fontWeight: FontWeight.bold)),
              SizedBox(height: 8),
              Text('শুধু মুসলিম পাত্র-পাত্রীর জন্য', style: TextStyle(color: Colors.white70)),
            ]),
          ),
          const SizedBox(height: 18),
          const Text('আমাদের সুবিধাসমূহ', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 10),
          const FeatureTile(icon: Icons.assignment_ind_outlined, title: 'বায়োডাটা তৈরি', subtitle: 'নিজের তথ্য দিয়ে বায়োডাটা প্রস্তুত করুন'),
          const FeatureTile(icon: Icons.manage_search, title: 'জীবনসঙ্গী অনুসন্ধান', subtitle: 'এলাকা ও পছন্দ অনুযায়ী খুঁজুন'),
          const FeatureTile(icon: Icons.verified_user_outlined, title: 'অ্যাডমিন যাচাই', subtitle: 'অনুমোদনের পর বায়োডাটা প্রকাশের পরিকল্পনা'),
          const FeatureTile(icon: Icons.lock_outline, title: 'গোপনীয়তা', subtitle: 'অনুমতি ছাড়া যোগাযোগের তথ্য প্রকাশ নয়'),
          const SizedBox(height: 12),
          const Text('প্রথম পর্যায়ের এলাকা', style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          Wrap(spacing: 8, children: districts.map((d) => Chip(label: Text(d))).toList()),
          const SizedBox(height: 14),
          const Text('নোট: এটি প্রাথমিক UI সংস্করণ। এখনো অনলাইন নিবন্ধন বা ডেটা সংরক্ষণ চালু হয়নি.',
            style: TextStyle(color: Colors.deepOrange, fontSize: 12)),
        ]),
      );
}

class FeatureTile extends StatelessWidget {
  final IconData icon; final String title; final String subtitle;
  const FeatureTile({super.key, required this.icon, required this.title, required this.subtitle});
  @override
  Widget build(BuildContext context) => Card(
    elevation: 0, child: ListTile(
      leading: CircleAvatar(backgroundColor: brand.withOpacity(.1), child: Icon(icon, color: brand)),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
      subtitle: Text(subtitle),
    ));
}

class SearchPage extends StatefulWidget {
  const SearchPage({super.key});
  @override
  State<SearchPage> createState() => _SearchPageState();
}
class _SearchPageState extends State<SearchPage> {
  String? district; String? gender; String? marital;
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('বায়োডাটা অনুসন্ধান')),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      const Text('আপনার পছন্দ অনুযায়ী খুঁজুন', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
      const SizedBox(height: 16),
      DropdownButtonFormField<String>(value: district, decoration: const InputDecoration(labelText: 'জেলা'),
        items: districts.map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
        onChanged: (v) => setState(() => district = v)),
      const SizedBox(height: 12),
      DropdownButtonFormField<String>(value: gender, decoration: const InputDecoration(labelText: 'যার বায়োডাটা খুঁজছেন'),
        items: const [DropdownMenuItem(value: 'পাত্র', child: Text('পাত্র')), DropdownMenuItem(value: 'পাত্রী', child: Text('পাত্রী'))],
        onChanged: (v) => setState(() => gender = v)),
      const SizedBox(height: 12),
      DropdownButtonFormField<String>(value: marital, decoration: const InputDecoration(labelText: 'বৈবাহিক অবস্থা'),
        items: const [DropdownMenuItem(value: 'অবিবাহিত', child: Text('অবিবাহিত')), DropdownMenuItem(value: 'বিধবা/বিপত্নীক', child: Text('বিধবা/বিপত্নীক')), DropdownMenuItem(value: 'তালাকপ্রাপ্ত', child: Text('তালাকপ্রাপ্ত'))],
        onChanged: (v) => setState(() => marital = v)),
      const SizedBox(height: 18),
      FilledButton.icon(onPressed: () => ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('অনুসন্ধান UI প্রস্তুত; বাস্তব ডেটাবেস এখনো সংযুক্ত নয়।'))),
        icon: const Icon(Icons.search), label: const Text('অনুসন্ধান করুন')),
      const SizedBox(height: 12),
      const Text('বাস্তব বায়োডাটা দেখতে Firebase ডেটাবেস সংযোগ ও অ্যাডমিন অনুমোদন ব্যবস্থা যুক্ত করতে হবে.',
        style: TextStyle(color: Colors.black54)),
    ]),
  );
}

class BiodataPage extends StatefulWidget {
  const BiodataPage({super.key});
  @override
  State<BiodataPage> createState() => _BiodataPageState();
}
class _BiodataPageState extends State<BiodataPage> {
  final formKey = GlobalKey<FormState>();
  final name = TextEditingController(); final age = TextEditingController();
  final education = TextEditingController(); final occupation = TextEditingController();
  String? gender; String? district; String? upazila; bool photoOptional = true;
  @override
  void dispose() { name.dispose(); age.dispose(); education.dispose(); occupation.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('বায়োডাটা তৈরি')),
    body: Form(key: formKey, child: ListView(padding: const EdgeInsets.all(16), children: [
      const Text('প্রাথমিক তথ্য', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
      const SizedBox(height: 14),
      TextFormField(controller: name, decoration: const InputDecoration(labelText: 'নাম (প্রদর্শনের নাম)'),
        validator: (v) => v == null || v.trim().isEmpty ? 'নাম লিখুন' : null),
      const SizedBox(height: 12),
      DropdownButtonFormField<String>(value: gender, decoration: const InputDecoration(labelText: 'আপনি'),
        items: const [DropdownMenuItem(value: 'পাত্র', child: Text('পাত্র')), DropdownMenuItem(value: 'পাত্রী', child: Text('পাত্রী'))],
        onChanged: (v) => setState(() => gender = v), validator: (v) => v == null ? 'নির্বাচন করুন' : null),
      const SizedBox(height: 12),
      TextFormField(controller: age, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'বয়স'),
        validator: (v) { final n = int.tryParse(v ?? ''); if (n == null) return 'সঠিক বয়স লিখুন'; if (n < 18) return '১৮ বছরের কম বয়সে নিবন্ধন করা যাবে না'; return null; }),
      const SizedBox(height: 12),
      TextFormField(controller: education, decoration: const InputDecoration(labelText: 'শিক্ষাগত যোগ্যতা')),
      const SizedBox(height: 12),
      TextFormField(controller: occupation, decoration: const InputDecoration(labelText: 'পেশা')),
      const SizedBox(height: 12),
      DropdownButtonFormField<String>(value: district, decoration: const InputDecoration(labelText: 'জেলা'),
        items: districts.map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
        onChanged: (v) => setState(() { district = v; upazila = null; })),
      const SizedBox(height: 12),
      DropdownButtonFormField<String>(value: upazila, decoration: const InputDecoration(labelText: 'উপজেলা'),
        items: (district == null ? <String>[] : upazilas[district] ?? []).map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
        onChanged: (v) => setState(() => upazila = v)),
      SwitchListTile(contentPadding: EdgeInsets.zero, value: photoOptional,
        onChanged: (v) => setState(() => photoOptional = v),
        title: const Text('ছবি ঐচ্ছিক রাখুন'), subtitle: const Text('ছবি না দিলেও বায়োডাটা তৈরি করা যাবে')),
      const SizedBox(height: 8),
      FilledButton(onPressed: () {
        if (!formKey.currentState!.validate()) return;
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('ফরম যাচাই হয়েছে। Firebase সংযোগ না থাকায় তথ্য সংরক্ষণ হয়নি।')));
      }, child: const Text('বায়োডাটা জমা দিন')),
      const SizedBox(height: 10),
      const Text('জমা দেওয়া তথ্য অ্যাডমিন যাচাইয়ের পর প্রকাশ হবে—এই প্রক্রিয়াটি backend সংযোগের পর কার্যকর হবে.',
        style: TextStyle(fontSize: 12, color: Colors.black54)),
    ])),
  );
}

class FavoritesPage extends StatelessWidget {
  const FavoritesPage({super.key});
  @override
  Widget build(BuildContext context) => const SimpleScaffold(title: 'পছন্দের তালিকা',
    child: Center(child: Padding(padding: EdgeInsets.all(24), child: Text('এখনো কোনো বায়োডাটা পছন্দের তালিকায় যোগ করা হয়নি।\\nবাস্তব সংরক্ষণ ব্যবস্থা পরে যুক্ত হবে।', textAlign: TextAlign.center))));
}
class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});
  @override
  Widget build(BuildContext context) => SimpleScaffold(title: 'আমার প্রোফাইল', child: ListView(padding: const EdgeInsets.all(16), children: const [
    ListTile(leading: Icon(Icons.person_outline), title: Text('নিবন্ধন / লগইন'), subtitle: Text('Firebase Authentication এখনো যুক্ত হয়নি')),
    Divider(),
    ListTile(leading: Icon(Icons.privacy_tip_outlined), title: Text('গোপনীয়তা ও নিরাপত্তা')),
    ListTile(leading: Icon(Icons.support_agent), title: Text('সহায়তা ও অভিযোগ')),
    ListTile(leading: Icon(Icons.admin_panel_settings_outlined), title: Text('অ্যাডমিন প্যানেল'), subtitle: Text('শুধু অনুমোদিত অ্যাডমিনের জন্য; role security পরে যুক্ত হবে')),
  ]));
}
class SimpleScaffold extends StatelessWidget {
  final String title; final Widget child;
  const SimpleScaffold({super.key, required this.title, required this.child});
  @override
  Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: Text(title)), body: child);
}
