# পরবর্তী কাজের তালিকা

এই সোর্স কোডকে বাস্তব অ্যাপে রূপ দিতে ক্রমানুসারে:

1. Flutter SDK দিয়ে `flutter pub get` এবং `flutter analyze` চালিয়ে UI পরীক্ষা।
2. Firebase project-এ Android app package name `com.bibahosondhan.app` মিলিয়ে FlutterFire configure।
3. Firebase Authentication: ইমেইল/ফোন OTP এবং account verification।
4. Firestore schema: users, biodatas, favorites, contactRequests, adminAuditLogs।
5. Security rules: ব্যবহারকারী কেবল নিজের draft; public কেবল approved biodata-এর অনুমোদিত field; admin custom claims দিয়ে review।
6. Admin role server-side trusted process দিয়ে assign করতে হবে; অ্যাপ থেকে নিজে admin হওয়া যাবে না।
7. Consent-based contact request; দুই পক্ষের অনুমোদনের আগে phone/email গোপন।
8. Privacy policy, terms, report/block, account deletion এবং abuse moderation।
9. Real device testing, backup, security review, তারপর signed APK/AAB।

**সতর্কতা:** Firebase-এর আগের Firestore locked rules (`allow read, write: if false`) আপাতত নিরাপদে রাখুন। পরীক্ষা করার জন্যও public read/write চালু করবেন না।
